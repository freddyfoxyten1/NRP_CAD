import { defineConfig, loadEnv, type ViteDevServer } from "vite";
import dyadComponentTagger from "@dyad-sh/react-vite-component-tagger";
import react from "@vitejs/plugin-react-swc";
import { neon } from "@neondatabase/serverless";
import path from "path";
import type { IncomingMessage, ServerResponse } from "http";

const REQUIRED_COMMUNITY_CODE = "SMR2026";
const DEFAULT_RANK = "member";
const DEFAULT_ROLE = "Community Members";
const DEFAULT_STATUS = "active";

const sendJson = (res: ServerResponse, statusCode: number, payload: unknown) => {
  res.statusCode = statusCode;
  res.setHeader("content-type", "application/json");
  res.end(JSON.stringify(payload));
};

const readJsonBody = async <T>(req: IncomingMessage) => {
  const chunks: Buffer[] = [];

  for await (const chunk of req) {
    chunks.push(typeof chunk === "string" ? Buffer.from(chunk) : chunk);
  }

  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}") as T;
};

const requireString = (value: unknown, field: string) => {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new Error(`${field} is required.`);
  }

  return value.trim();
};

const digest = async (value: string) => {
  const encoded = new TextEncoder().encode(value);
  const hashBuffer = await crypto.subtle.digest("SHA-256", encoded);
  return Array.from(new Uint8Array(hashBuffer), (byte) => byte.toString(16).padStart(2, "0")).join("");
};

const hashPassword = async (password: string, salt: string) => digest(`${salt}:${password}`);

const cadApiPlugin = (databaseUrl: string | undefined, adminCode: string) => ({
  name: "cad-api-routes",
  configureServer(server: ViteDevServer) {
    server.middlewares.use(async (req, res, next) => {
      const pathname = req.url?.split("?")[0];

      if (
        pathname !== "/api/admin/members" &&
        pathname !== "/api/cad-profiles" &&
        pathname !== "/api/cad-auth/sign-in" &&
        pathname !== "/api/cad-auth/session-status"
      ) {
        next();
        return;
      }

      if (!databaseUrl) {
        sendJson(res, 500, { error: "DATABASE_URL is not configured." });
        return;
      }

      const sql = neon(databaseUrl);

      try {
        if (pathname === "/api/admin/members") {
          if (req.method !== "GET" && req.method !== "DELETE" && req.method !== "PATCH") {
            sendJson(res, 405, { error: "Method not allowed." });
            return;
          }

          if (req.headers["x-admin-code"] !== adminCode) {
            sendJson(res, 403, { error: "Admin access required." });
            return;
          }

          if (req.method === "DELETE") {
            const url = new URL(req.url ?? "/api/admin/members", "http://localhost");
            const memberId = url.searchParams.get("id");

            if (memberId) {
              const id = Number(memberId);

              if (!Number.isInteger(id)) {
                sendJson(res, 400, { error: "Invalid member ID." });
                return;
              }

              const [member] = await sql<{ id: number; protected: boolean }[]>`
                SELECT id::int, (lower(role) IN ('executive board', 'management', 'admin')) AS protected
                FROM cad_user_profiles
                WHERE id = ${id}
                LIMIT 1
              `;

              if (!member) {
                sendJson(res, 200, { deleted_count: 0, protected_count: 0 });
                return;
              }

              if (member.protected) {
                sendJson(res, 200, { deleted_count: 0, protected_count: 1 });
                return;
              }

              const [result] = await sql<{ deleted_count: number; deleted_ids: number[] }[]>`
                WITH deleted AS (
                  DELETE FROM cad_user_profiles
                  WHERE id = ${id}
                  RETURNING id::int
                )
                SELECT
                  COUNT(*)::int AS deleted_count,
                  COALESCE(array_agg(id), '{}'::int[]) AS deleted_ids
                FROM deleted
              `;

              sendJson(res, 200, {
                deleted_count: result?.deleted_count ?? 0,
                deleted_ids: result?.deleted_ids ?? [],
                protected_count: 0,
              });
              return;
            }

            const [result] = await sql<{ deleted_count: number; protected_count: number; deleted_ids: number[] }[]>`
              WITH protected AS (
                SELECT COUNT(*)::int AS protected_count
                FROM cad_user_profiles
                WHERE lower(status) = 'active' AND lower(role) IN ('executive board', 'management', 'admin')
              ),
              deleted AS (
                DELETE FROM cad_user_profiles
                WHERE lower(status) = 'active' AND lower(role) NOT IN ('executive board', 'management', 'admin')
                RETURNING id::int
              )
              SELECT
                (SELECT COUNT(*)::int FROM deleted) AS deleted_count,
                (SELECT COALESCE(array_agg(id), '{}'::int[]) FROM deleted) AS deleted_ids,
                (SELECT protected_count FROM protected) AS protected_count
            `;

            sendJson(res, 200, result ?? { deleted_count: 0, deleted_ids: [], protected_count: 0 });
            return;
          }

          if (req.method === "PATCH") {
            const body = await readJsonBody<{
              id?: number;
              auth_user_id?: string | null;
              username?: string;
              discord_username?: string;
              discord_id?: string;
              email?: string;
              community_code?: string;
              status?: string;
              rank?: string;
              role?: string;
            }>(req);
            const id = Number(body.id);
            const authUserId = body.auth_user_id === null ? null : (typeof body.auth_user_id === "string" ? body.auth_user_id.trim() || null : null);
            const username = requireString(body.username, "Username");
            const discordUsername = requireString(body.discord_username, "Discord username");
            const discordId = requireString(body.discord_id, "Discord ID");
            const email = requireString(body.email, "Email").toLowerCase();
            const communityCode = requireString(body.community_code, "Community code").toUpperCase();
            const status = requireString(body.status, "Status").toLowerCase();
            const rank = requireString(body.rank, "Rank");
            const role = requireString(body.role, "Role").toLowerCase();

            if (!Number.isInteger(id)) {
              sendJson(res, 400, { error: "Invalid member ID." });
              return;
            }

            const [member] = await sql`
              UPDATE cad_user_profiles
              SET
                auth_user_id = ${authUserId},
                username = ${username},
                discord_username = ${discordUsername},
                discord_id = ${discordId},
                email = ${email},
                community_code = ${communityCode},
                status = ${status},
                rank = ${rank},
                role = ${role},
                updated_at = now()
              WHERE id = ${id}
              RETURNING
                id::int,
                auth_user_id,
                username,
                discord_username,
                discord_id,
                email,
                community_code,
                status,
                rank,
                role,
                created_at::text,
                updated_at::text
            `;

            if (!member) {
              sendJson(res, 404, { error: "Member not found." });
              return;
            }

            sendJson(res, 200, member);
            return;
          }

          const members = await sql`
            SELECT
              id::int,
              auth_user_id,
              username,
              discord_username,
              discord_id,
              email,
              community_code,
              status,
              rank,
              role,
              created_at::text,
              updated_at::text
            FROM cad_user_profiles
            ORDER BY created_at DESC
          `;

          sendJson(res, 200, members);
          return;
        }

        if (pathname === "/api/cad-auth/session-status") {
          if (req.method !== "POST") {
            sendJson(res, 405, { error: "Method not allowed." });
            return;
          }

          const body = await readJsonBody<{ id?: number; email?: string }>(req);
          const id = Number(body.id);
          const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";

          if (!Number.isInteger(id) || !email) {
            sendJson(res, 200, { active: false });
            return;
          }

          const [account] = await sql<{
            id: number;
            username: string;
            email: string;
            rank: string;
            role: string;
            status: string;
          }[]>`
            SELECT id::int, username, email, rank, role, status
            FROM cad_user_profiles
            WHERE id = ${id} AND lower(email) = ${email}
            LIMIT 1
          `;

          sendJson(res, 200, account ? { active: true, account } : { active: false });
          return;
        }

        if (pathname === "/api/cad-auth/sign-in") {
          if (req.method !== "POST") {
            sendJson(res, 405, { error: "Method not allowed." });
            return;
          }

          const body = await readJsonBody<{ username?: string; password?: string }>(req);
          const username = typeof body.username === "string" ? body.username.trim().toLowerCase() : "";
          const password = typeof body.password === "string" ? body.password : "";

          if (!username || !password) {
            sendJson(res, 200, null);
            return;
          }

          const [account] = await sql<{
            id: number;
            username: string;
            email: string;
            rank: string;
            role: string;
            status: string;
            password_salt: string | null;
            password_hash: string | null;
          }[]>`
            SELECT
              id::int,
              username,
              email,
              rank,
              role,
              status,
              password_salt,
              password_hash
            FROM cad_user_profiles
            WHERE lower(username) = ${username}
            LIMIT 1
          `;

          if (!account?.password_salt || !account.password_hash) {
            sendJson(res, 200, null);
            return;
          }

          const passwordHash = await hashPassword(password, account.password_salt);

          if (passwordHash !== account.password_hash) {
            sendJson(res, 200, null);
            return;
          }

          sendJson(res, 200, {
            id: account.id,
            username: account.username,
            email: account.email,
            rank: account.rank,
            role: account.role,
            status: account.status,
          });
          return;
        }

        if (req.method !== "POST") {
          sendJson(res, 405, { error: "Method not allowed." });
          return;
        }

        const body = await readJsonBody<{
          auth_user_id?: string;
          username?: string;
          discord_username?: string;
          discord_id?: string;
          email?: string;
          community_code?: string;
          role?: string;
          password_salt?: string;
          password_hash?: string;
        }>(req);
        const authUserId = requireString(body.auth_user_id, "Auth user ID");
        const username = requireString(body.username, "Username");
        const discordUsername = requireString(body.discord_username, "Discord username");
        const discordId = requireString(body.discord_id, "Discord ID");
        const email = requireString(body.email, "Email").toLowerCase();
        const communityCode = requireString(body.community_code, "Community code").toUpperCase();
        const role = typeof body.role === "string" && body.role.trim() ? body.role.trim().toLowerCase() : DEFAULT_ROLE;
        const passwordSalt = requireString(body.password_salt, "Password salt");
        const passwordHash = requireString(body.password_hash, "Password hash");

        if (communityCode !== REQUIRED_COMMUNITY_CODE) {
          sendJson(res, 403, { error: "Invalid community code." });
          return;
        }

        const [profile] = await sql`
          INSERT INTO cad_user_profiles (
            auth_user_id,
            username,
            discord_username,
            discord_id,
            email,
            community_code,
            status,
            rank,
            role,
            password_salt,
            password_hash
          ) VALUES (
            ${authUserId},
            ${username},
            ${discordUsername},
            ${discordId},
            ${email},
            ${communityCode},
            ${DEFAULT_STATUS},
            ${DEFAULT_RANK},
            ${role},
            ${passwordSalt},
            ${passwordHash}
          )
          ON CONFLICT (email) DO UPDATE SET
            auth_user_id = EXCLUDED.auth_user_id,
            username = EXCLUDED.username,
            discord_username = EXCLUDED.discord_username,
            discord_id = EXCLUDED.discord_id,
            community_code = EXCLUDED.community_code,
            status = EXCLUDED.status,
            role = EXCLUDED.role,
            password_salt = EXCLUDED.password_salt,
            password_hash = EXCLUDED.password_hash,
            updated_at = now()
          RETURNING id::int
        `;

        sendJson(res, 200, profile);
      } catch (error) {
        sendJson(res, 500, { error: error instanceof Error ? error.message : "CAD API request failed." });
      }
    });
  },
});

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const databaseUrl = process.env.DATABASE_URL ?? env.DATABASE_URL;
  const adminCode = process.env.ADMIN_PORTAL_CODE ?? env.ADMIN_PORTAL_CODE ?? "ADMIN2026";

  return {
    server: {
      host: "::",
      port: 8080,
    },
    define: {
      __APP_LAST_UPDATED__: JSON.stringify(new Date().toISOString()),
    },
    plugins: [cadApiPlugin(databaseUrl, adminCode), dyadComponentTagger(), react()],
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
  };
});
