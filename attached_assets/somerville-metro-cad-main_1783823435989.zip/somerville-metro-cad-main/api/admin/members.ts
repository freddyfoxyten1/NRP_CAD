import { neon } from '@neondatabase/serverless';

export const config = { runtime: 'edge' };

const ADMIN_CODE = process.env.ADMIN_PORTAL_CODE ?? 'ADMIN2026';

type UpdateMemberInput = {
  id?: number;
  username?: string;
  discord_username?: string;
  discord_id?: string;
  email?: string;
  community_code?: string;
  status?: string;
  rank?: string;
  role?: string;
  auth_user_id?: string | null;
};

const jsonError = (message: string, status: number) => Response.json({ error: message }, { status });
const clean = (value: unknown) => (typeof value === 'string' ? value.trim() : '');

export default async function handler(request: Request) {
  if (!['GET', 'DELETE', 'PATCH'].includes(request.method)) {
    return jsonError('Method not allowed.', 405);
  }

  if (request.headers.get('x-admin-code') !== ADMIN_CODE) {
    return jsonError('Admin access required.', 403);
  }

  if (!process.env.DATABASE_URL) {
    return jsonError('DATABASE_URL is not configured.', 500);
  }

  const sql = neon(process.env.DATABASE_URL);

  if (request.method === 'DELETE') {
    const url = new URL(request.url);
    const memberId = url.searchParams.get('id');

    if (memberId) {
      const id = Number(memberId);

      if (!Number.isInteger(id)) {
        return jsonError('Invalid member ID.', 400);
      }

      const [member] = await sql<{ id: number; protected: boolean }[]>`
        SELECT id::int, (lower(role) IN ('executive board', 'management', 'admin')) AS protected
        FROM cad_user_profiles
        WHERE id = ${id}
        LIMIT 1
      `;

      if (!member) {
        return Response.json({ deleted_count: 0, protected_count: 0 });
      }

      if (member.protected) {
        return Response.json({ deleted_count: 0, protected_count: 1 });
      }

      const [result] = await sql<{ deleted_count: number; deleted_ids: number[] }[]>`
        WITH deleted AS (
          DELETE FROM cad_user_profiles
          WHERE id = ${id}
          RETURNING id::int
        )
        SELECT
          COUNT(*)::int AS deleted_count,
          COALESCE(array_agg(id), '{}'::int[]) AS deleted_ids
        FROM deleted
      `;

      return Response.json({
        deleted_count: result?.deleted_count ?? 0,
        deleted_ids: result?.deleted_ids ?? [],
        protected_count: 0,
      });
    }

    const [result] = await sql<{ deleted_count: number; protected_count: number; deleted_ids: number[] }[]>`
      WITH protected AS (
        SELECT COUNT(*)::int AS protected_count
        FROM cad_user_profiles
        WHERE lower(status) = 'active' AND lower(role) IN ('executive board', 'management', 'admin')
      ),
      deleted AS (
        DELETE FROM cad_user_profiles
        WHERE lower(status) = 'active' AND lower(role) NOT IN ('executive board', 'management', 'admin')
        RETURNING id::int
      )
      SELECT
        (SELECT COUNT(*)::int FROM deleted) AS deleted_count,
        (SELECT COALESCE(array_agg(id), '{}'::int[]) FROM deleted) AS deleted_ids,
        (SELECT protected_count FROM protected) AS protected_count
    `;

    return Response.json(result ?? { deleted_count: 0, deleted_ids: [], protected_count: 0 });
  }

  if (request.method === 'PATCH') {
    const body = (await request.json()) as UpdateMemberInput;
    const id = Number(body.id);

    if (!Number.isInteger(id)) {
      return jsonError('Invalid member ID.', 400);
    }

    const username = clean(body.username);
    const discordUsername = clean(body.discord_username);
    const discordId = clean(body.discord_id);
    const email = clean(body.email).toLowerCase();
    const communityCode = clean(body.community_code).toUpperCase();
    const status = clean(body.status).toLowerCase();
    const rank = clean(body.rank);
    const role = clean(body.role).toLowerCase();
    const authUserId = body.auth_user_id === null ? null : clean(body.auth_user_id) || null;

    if (!username || !discordUsername || !discordId || !email || !communityCode || !status || !rank || !role) {
      return jsonError('All editable account fields are required.', 400);
    }

    const [member] = await sql`
      UPDATE cad_user_profiles
      SET
        auth_user_id = ${authUserId},
        username = ${username},
        discord_username = ${discordUsername},
        discord_id = ${discordId},
        email = ${email},
        community_code = ${communityCode},
        status = ${status},
        rank = ${rank},
        role = ${role},
        updated_at = now()
      WHERE id = ${id}
      RETURNING
        id::int,
        auth_user_id,
        username,
        discord_username,
        discord_id,
        email,
        community_code,
        status,
        rank,
        role,
        created_at::text,
        updated_at::text
    `;

    return member ? Response.json(member) : jsonError('Member not found.', 404);
  }

  const members = await sql`
    SELECT
      id::int,
      auth_user_id,
      username,
      discord_username,
      discord_id,
      email,
      community_code,
      status,
      rank,
      role,
      created_at::text,
      updated_at::text
    FROM cad_user_profiles
    ORDER BY created_at DESC
  `;

  return Response.json(members);
}
