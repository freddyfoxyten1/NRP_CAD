import { neon } from '@neondatabase/serverless';

export const config = { runtime: 'edge' };

type SignInInput = {
  username?: string;
  password?: string;
};

const digest = async (value: string) => {
  const encoded = new TextEncoder().encode(value);
  const hashBuffer = await crypto.subtle.digest('SHA-256', encoded);
  return Array.from(new Uint8Array(hashBuffer), (byte) => byte.toString(16).padStart(2, '0')).join('');
};

const hashPassword = async (password: string, salt: string) => digest(`${salt}:${password}`);

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return Response.json({ error: 'Method not allowed.' }, { status: 405 });
  }

  if (!process.env.DATABASE_URL) {
    return Response.json({ error: 'DATABASE_URL is not configured.' }, { status: 500 });
  }

  const body = (await request.json()) as SignInInput;
  const username = typeof body.username === 'string' ? body.username.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';

  if (!username || !password) {
    return Response.json(null);
  }

  const sql = neon(process.env.DATABASE_URL);
  const [account] = await sql<{
    id: number;
    username: string;
    email: string;
    rank: string;
    role: string;
    status: string;
    password_salt: string | null;
    password_hash: string | null;
  }[]>`
    SELECT
      id::int,
      username,
      email,
      rank,
      role,
      status,
      password_salt,
      password_hash
    FROM cad_user_profiles
    WHERE lower(username) = ${username}
    LIMIT 1
  `;

  if (!account?.password_salt || !account.password_hash) {
    return Response.json(null);
  }

  const passwordHash = await hashPassword(password, account.password_salt);

  if (passwordHash !== account.password_hash) {
    return Response.json(null);
  }

  return Response.json({
    id: account.id,
    username: account.username,
    email: account.email,
    rank: account.rank,
    role: account.role,
    status: account.status,
  });
}
