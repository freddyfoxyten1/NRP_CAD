import { neon } from '@neondatabase/serverless';

export const config = { runtime: 'edge' };

type SessionStatusInput = {
  id?: number;
  email?: string;
};

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return Response.json({ error: 'Method not allowed.' }, { status: 405 });
  }

  if (!process.env.DATABASE_URL) {
    return Response.json({ error: 'DATABASE_URL is not configured.' }, { status: 500 });
  }

  const body = (await request.json()) as SessionStatusInput;
  const id = Number(body.id);
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';

  if (!Number.isInteger(id) || !email) {
    return Response.json({ active: false });
  }

  const sql = neon(process.env.DATABASE_URL);
  const [account] = await sql<{
    id: number;
    username: string;
    email: string;
    rank: string;
    role: string;
    status: string;
  }[]>`
    SELECT id::int, username, email, rank, role, status
    FROM cad_user_profiles
    WHERE id = ${id} AND lower(email) = ${email}
    LIMIT 1
  `;

  return Response.json(account ? { active: true, account } : { active: false });
}
