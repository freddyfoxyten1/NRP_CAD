import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AtSign, Hash, Key, Lock, Mail, User, X } from 'lucide-react';
import { toast } from 'sonner';
import LastUpdatedBadge from '@/components/LastUpdatedBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { createCadLocalAccount, signInCadLocalAccount } from '@/lib/cad-local-accounts';
import { setCadSession } from '@/lib/cad-session';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AuthTab = 'signin' | 'signup';

const REQUIRED_COMMUNITY_CODE = 'SMR2026';

const LoginModal = ({ isOpen, onClose }: LoginModalProps) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<AuthTab>('signin');
  const [signInData, setSignInData] = useState({ username: '', password: '' });
  const [signUpData, setSignUpData] = useState({
    username: '',
    discordUsername: '',
    discordId: '',
    email: '',
    password: '',
    confirmPassword: '',
    communityCode: '',
  });
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const switchTab = (tab: AuthTab) => {
    setActiveTab(tab);
    setError(null);
  };

  const handleSignInSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const profile = await signInCadLocalAccount(signInData.username, signInData.password);

      if (!profile) {
        setError('Invalid username or password.');
        return;
      }

      setCadSession(profile);
      toast.success('Signed in to the CAD terminal.');
      onClose();
      navigate('/portal');
    } catch (authError) {
      setError(authError instanceof Error ? authError.message : 'Unable to sign in.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignUpSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    if (signUpData.password !== signUpData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (signUpData.communityCode.trim().toUpperCase() !== REQUIRED_COMMUNITY_CODE) {
      setError(`Community code must be ${REQUIRED_COMMUNITY_CODE}.`);
      return;
    }

    setIsSubmitting(true);

    try {
      const profile = await createCadLocalAccount(signUpData);

      setCadSession(profile);
      toast.success('Account created and saved.');
      setSignUpData({
        username: '',
        discordUsername: '',
        discordId: '',
        email: '',
        password: '',
        confirmPassword: '',
        communityCode: '',
      });
      setSignInData({ username: profile.username, password: '' });
      onClose();
      navigate('/portal');
    } catch (accountError) {
      setError(accountError instanceof Error ? accountError.message : 'Unable to create account.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputClassName =
    'h-12 rounded-md border-[#202a3a] bg-[#080d15] pl-11 text-[13px] text-white shadow-inner shadow-black/20 placeholder:text-[#66748a] focus-visible:ring-2 focus-visible:ring-[#2f6df6]/70 focus-visible:ring-offset-0';
  const iconClassName = 'pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#68758a]';
  const labelClassName = 'text-[10px] font-black uppercase tracking-[0.16em] text-[#72809a]';

  return (
    <div className="fixed inset-0 z-50 flex min-h-screen items-center justify-center overflow-y-auto bg-[#03070c]/95 px-4 py-8 text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_center,rgba(21,34,56,0.42)_0,rgba(3,7,12,0)_48%)]" />

      <div className="relative w-full max-w-[430px] rounded-2xl border border-[#192336] bg-[#0d1422] p-7 shadow-[0_28px_80px_rgba(0,0,0,0.72)] sm:p-8">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-5 top-5 rounded-full p-1 text-[#6d7687] transition-colors hover:bg-white/5 hover:text-white"
          aria-label="Close sign in modal"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="mb-7 text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.48em] text-[#2f70ff]">
            Somerville Metro
          </p>
          <h2 className="mt-3 text-[28px] font-black leading-none tracking-[-0.04em] text-white drop-shadow-[2px_2px_0_rgba(37,99,235,0.45)] sm:text-[31px]">
            CAD/MDT Terminal
          </h2>
        </div>

        <div className="mb-7 grid grid-cols-2 border-b border-[#202a3a]">
          <button
            type="button"
            onClick={() => switchTab('signin')}
            className={`pb-3 text-sm font-bold transition-colors ${
              activeTab === 'signin'
                ? 'border-b-2 border-[#3a77ff] text-white'
                : 'text-[#6f7d92] hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => switchTab('signup')}
            className={`pb-3 text-sm font-bold transition-colors ${
              activeTab === 'signup'
                ? 'border-b-2 border-[#3a77ff] text-white'
                : 'text-[#6f7d92] hover:text-white'
            }`}
          >
            Create Account
          </button>
        </div>

        {error && (
          <div className="mb-5 rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-3 text-center text-sm font-semibold text-red-200">
            {error}
          </div>
        )}

        {activeTab === 'signin' ? (
          <form onSubmit={handleSignInSubmit} className="space-y-4">
            <div className="relative">
              <User className={iconClassName} aria-hidden="true" />
              <Input
                type="text"
                placeholder="Username"
                value={signInData.username}
                onChange={(event) => setSignInData({ ...signInData, username: event.target.value })}
                autoComplete="username"
                required
                className={inputClassName}
              />
            </div>

            <div className="relative">
              <Lock className={iconClassName} aria-hidden="true" />
              <Input
                type="password"
                placeholder="Password"
                value={signInData.password}
                onChange={(event) => setSignInData({ ...signInData, password: event.target.value })}
                autoComplete="current-password"
                required
                className={inputClassName}
              />
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="h-12 w-full rounded-md bg-[#2f66ee] text-sm font-black text-white shadow-[0_12px_28px_rgba(47,102,238,0.28)] transition-all hover:-translate-y-0.5 hover:bg-[#3977ff] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {isSubmitting ? 'Signing in...' : 'Sign in to Terminal'}
            </Button>
          </form>
        ) : (
          <form
            onSubmit={handleSignUpSubmit}
            className="max-h-[380px] space-y-5 overflow-y-auto pr-4 [scrollbar-color:#6b7280_#f5f5f5] [scrollbar-width:thin] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#6b7280] [&::-webkit-scrollbar-track]:bg-[#f5f5f5] [&::-webkit-scrollbar]:w-3"
          >
            <div className="space-y-2">
              <Label htmlFor="cad-username" className={labelClassName}>
                Username
              </Label>
              <div className="relative">
                <User className={iconClassName} aria-hidden="true" />
                <Input
                  id="cad-username"
                  type="text"
                  placeholder="Your CAD username"
                  value={signUpData.username}
                  onChange={(event) => setSignUpData({ ...signUpData, username: event.target.value })}
                  autoComplete="username"
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="discord-username" className={labelClassName}>
                Discord Username
              </Label>
              <div className="relative">
                <AtSign className={iconClassName} aria-hidden="true" />
                <Input
                  id="discord-username"
                  type="text"
                  placeholder="e.g. john_doe"
                  value={signUpData.discordUsername}
                  onChange={(event) => setSignUpData({ ...signUpData, discordUsername: event.target.value })}
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="discord-id" className={labelClassName}>
                Discord ID
              </Label>
              <div className="relative">
                <Hash className={iconClassName} aria-hidden="true" />
                <Input
                  id="discord-id"
                  type="text"
                  placeholder="e.g. 123456789012345678"
                  value={signUpData.discordId}
                  onChange={(event) => setSignUpData({ ...signUpData, discordId: event.target.value })}
                  inputMode="numeric"
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className={labelClassName}>
                Email
              </Label>
              <div className="relative">
                <Mail className={iconClassName} aria-hidden="true" />
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={signUpData.email}
                  onChange={(event) => setSignUpData({ ...signUpData, email: event.target.value })}
                  autoComplete="email"
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className={labelClassName}>
                Password
              </Label>
              <div className="relative">
                <Lock className={iconClassName} aria-hidden="true" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={signUpData.password}
                  onChange={(event) => setSignUpData({ ...signUpData, password: event.target.value })}
                  autoComplete="new-password"
                  minLength={8}
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password" className={labelClassName}>
                Confirm Password
              </Label>
              <div className="relative">
                <Lock className={iconClassName} aria-hidden="true" />
                <Input
                  id="confirm-password"
                  type="password"
                  placeholder="••••••••"
                  value={signUpData.confirmPassword}
                  onChange={(event) => setSignUpData({ ...signUpData, confirmPassword: event.target.value })}
                  autoComplete="new-password"
                  minLength={8}
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="community-code" className={labelClassName}>
                Community Code
              </Label>
              <div className="relative">
                <Key className={iconClassName} aria-hidden="true" />
                <Input
                  id="community-code"
                  type="text"
                  placeholder="Enter community code"
                  value={signUpData.communityCode}
                  onChange={(event) => setSignUpData({ ...signUpData, communityCode: event.target.value.toUpperCase() })}
                  required
                  className={inputClassName}
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="h-12 w-full rounded-md bg-[#2f66ee] text-sm font-black text-white shadow-[0_12px_28px_rgba(47,102,238,0.28)] transition-all hover:-translate-y-0.5 hover:bg-[#3977ff] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {isSubmitting ? 'Creating Account...' : 'Create Account'}
            </Button>
          </form>
        )}
      </div>

      <LastUpdatedBadge />
    </div>
  );
};

export default LoginModal;