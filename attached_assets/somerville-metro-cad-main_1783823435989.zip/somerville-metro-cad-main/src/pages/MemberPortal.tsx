import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock3, Megaphone, Shield, Users, Wifi } from 'lucide-react';
import { toast } from 'sonner';
import LastUpdatedBadge from '@/components/LastUpdatedBadge';
import { getCadLocalStats } from '@/lib/cad-local-accounts';
import { clearCadSession, getCadSession, setCadSession, type CadSession } from '@/lib/cad-session';

type PortalData = {
  profile: {
    username: string;
    rank: string;
    role: string;
    status: string;
    email: string;
  };
  stats: {
    totalMembers: number;
    totalPlayTime: string;
    totalOnlineMembers: number;
  };
};

const navItems = [
  'Dashboard',
  'CAD System',
  'Reports',
  'Civilian Portal',
  'Department of Public Safety',
  'Somerville Fire Department',
  'Penal Code',
  'Supervisor',
  'Staff',
];

const statusCards = [
  {
    label: 'Total Members',
    accent: 'text-[#ff5d66]',
    icon: Users,
    valueKey: 'totalMembers' as const,
  },
  {
    label: 'Total Play Time',
    accent: 'text-[#f4c542]',
    icon: Clock3,
    valueKey: 'totalPlayTime' as const,
  },
  {
    label: 'Total Online Members',
    accent: 'text-[#4384ff]',
    icon: Wifi,
    valueKey: 'totalOnlineMembers' as const,
  },
];

const ADMIN_CODE_STORAGE_KEY = 'somerville-admin-code';
const ADMIN_ROLE_GROUPS = ['Executive Board', 'Management', 'Admin'];

const hasAdminRole = (role: string) => ADMIN_ROLE_GROUPS.some((group) => group.toLowerCase() === role.trim().toLowerCase());

const toPortalData = (session: CadSession): PortalData => ({
  profile: {
    username: session.username,
    rank: session.rank,
    role: session.role,
    status: session.status,
    email: session.email,
  },
  stats: getCadLocalStats(),
});

const MemberPortal = () => {
  const navigate = useNavigate();
  const [portalData, setPortalData] = useState<PortalData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSigningOut, setIsSigningOut] = useState(false);

  useEffect(() => {
    let isMounted = true;

    const validateSession = async (showLoading: boolean) => {
      const session = getCadSession();

      if (!session) {
        navigate('/', { replace: true });
        return;
      }

      if (showLoading) {
        setIsLoading(true);
      }

      try {
        const response = await fetch('/api/cad-auth/session-status', {
          method: 'POST',
          headers: { 'content-type': 'application/json', accept: 'application/json' },
          body: JSON.stringify({ id: session.id, email: session.email }),
        });
        const contentType = response.headers.get('content-type') ?? '';

        if (!response.ok || !contentType.includes('application/json')) {
          throw new Error('Unable to verify member session.');
        }

        const result = (await response.json()) as {
          active: boolean;
          account?: CadSession;
        };

        if (!result.active || !result.account) {
          clearCadSession();
          sessionStorage.removeItem(ADMIN_CODE_STORAGE_KEY);
          toast.error('Your CAD account was deleted. You have been signed out.');
          navigate('/', { replace: true });
          return;
        }

        setCadSession(result.account);

        if (isMounted) {
          setPortalData(toPortalData(result.account));
          setError(null);
          setIsLoading(false);
        }
      } catch {
        if (isMounted) {
          setPortalData(toPortalData(session));
          setError(null);
          setIsLoading(false);
        }
      }
    };

    validateSession(true);
    const interval = window.setInterval(() => validateSession(false), 10000);

    return () => {
      isMounted = false;
      window.clearInterval(interval);
    };
  }, [navigate]);

  const handleSignOut = async () => {
    setIsSigningOut(true);
    clearCadSession();
    sessionStorage.removeItem(ADMIN_CODE_STORAGE_KEY);
    toast.success('Signed out of the member portal.');
    navigate('/', { replace: true });
  };

  const handleAdminPortal = () => {
    navigate('/admin');
  };

  const username = portalData?.profile.username ?? 'Member';
  const rank = portalData?.profile.rank ?? 'Community Members';
  const canAccessAdminPortal = hasAdminRole(portalData?.profile.role ?? '');

  return (
    <main className="min-h-screen bg-[#02060b] text-white">
      <div className="flex min-h-screen flex-col lg:flex-row">
        <aside className="border-b border-[#182232] bg-[#03070c] px-5 py-5 lg:fixed lg:inset-y-0 lg:left-0 lg:w-[265px] lg:border-b-0 lg:border-r">
          <div>
            <h1 className="text-xl font-black tracking-[-0.04em] text-white">Member Portal</h1>
            <p className="mt-2 text-sm font-black leading-none text-[#3f85ff]">{username}</p>
            <p className="mt-1 text-[10px] font-black uppercase tracking-[0.22em] text-[#7b8ca7]">
              {rank}
            </p>
          </div>

          <nav className="mt-8 flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
            {navItems.map((item, index) => (
              <button
                key={item}
                type="button"
                className={`shrink-0 rounded-md px-4 py-3 text-left text-sm font-semibold transition-colors ${
                  index === 0
                    ? 'border-l-2 border-[#4384ff] bg-[#081329] text-white'
                    : 'text-[#a8b7cd] hover:bg-[#08111f] hover:text-white'
                }`}
              >
                {item}
              </button>
            ))}
          </nav>

          {canAccessAdminPortal && (
            <button
              type="button"
              onClick={handleAdminPortal}
              className="mt-6 flex w-full items-center gap-3 border-t border-[#182232] px-4 pt-6 text-left text-sm font-black uppercase text-[#ff5d5d] transition-colors hover:text-[#ff8585] lg:mt-5"
            >
              <Shield className="h-4 w-4" />
              Admin Portal
            </button>
          )}
        </aside>

        <section className="flex min-h-screen flex-1 flex-col lg:ml-[265px]">
          <header className="flex items-center justify-between border-b border-[#182232] px-5 py-4 sm:px-8 lg:px-9">
            <p className="text-sm font-black uppercase tracking-[0.08em] text-white">Somerville Metro</p>
            <div className="hidden items-center gap-2 rounded-full border border-[#173053] bg-[#071120] px-4 py-2 sm:flex">
              <span className="h-2 w-2 rounded-full bg-[#4384ff]" />
              <span className="text-[10px] font-black uppercase tracking-[0.34em] text-[#4384ff]">
                Terminal Online
              </span>
            </div>
            <button
              type="button"
              onClick={handleSignOut}
              disabled={isSigningOut}
              className="rounded-full px-3 py-2 text-sm font-bold text-[#dce7f8] transition-colors hover:bg-white/5 hover:text-[#4384ff] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSigningOut ? 'Signing out...' : 'Sign out'}
            </button>
          </header>

          <div className="flex-1 px-5 py-8 sm:px-8 lg:px-9">
            {isLoading ? (
              <div className="flex min-h-[55vh] items-center justify-center rounded-xl border border-[#172235] bg-[#0d1422] text-sm font-bold text-[#8ea1bb]">
                Loading member portal...
              </div>
            ) : error ? (
              <div className="rounded-xl border border-red-500/25 bg-red-500/10 p-6 text-sm font-bold text-red-100">
                {error}
              </div>
            ) : (
              <>
                <section className="mb-8">
                  <h2 className="text-3xl font-black leading-none tracking-[-0.05em] text-white sm:text-4xl">
                    Welcome back, {username}
                  </h2>
                  <p className="mt-2 text-sm text-[#8392aa] sm:text-base">
                    You are currently logged in as{' '}
                    <span className="font-bold text-[#4384ff]">{rank}</span>
                  </p>
                </section>

                <section className="grid gap-5 lg:grid-cols-3">
                  {statusCards.map(({ label, accent, icon: Icon, valueKey }) => (
                    <div
                      key={label}
                      className="rounded-xl border border-[#172235] bg-[#0d1422] p-6 shadow-[0_18px_38px_rgba(0,0,0,0.2)]"
                    >
                      <div className="flex items-start justify-between gap-5">
                        <div>
                          <p className={`text-[10px] font-black uppercase tracking-[0.2em] ${accent}`}>
                            {label}
                          </p>
                          <p className="mt-4 text-2xl font-black tracking-[-0.04em] text-white">
                            {portalData?.stats[valueKey]}
                          </p>
                        </div>
                        <Icon className="h-7 w-7 text-[#647086] opacity-80" />
                      </div>
                    </div>
                  ))}
                </section>

                <section className="mt-8 min-h-[430px] rounded-xl border border-[#172235] bg-[#0d1422] p-7 shadow-[0_22px_55px_rgba(0,0,0,0.22)]">
                  <div className="flex items-center gap-3">
                    <Megaphone className="h-5 w-5 text-[#bc74ff]" />
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[#c06dff]">
                      Community Announcements
                    </h3>
                  </div>

                  <div className="flex min-h-[320px] items-center justify-center text-center">
                    <p className="text-sm italic text-[#526179]">No recent announcements to display.</p>
                  </div>
                </section>
              </>
            )}
          </div>

          <LastUpdatedBadge />
        </section>
      </div>
    </main>
  );
};

export default MemberPortal;