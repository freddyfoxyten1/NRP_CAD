import { useState } from "react";
import { FileText, Radio, Shield } from "lucide-react";
import { MadeWithDyad } from "@/components/made-with-dyad";
import { Button } from "@/components/ui/button";
import LastUpdatedBadge from "@/components/LastUpdatedBadge";
import LoginModal from "@/components/LoginModal";

const featureCards = [
  {
    title: "Live Dispatch",
    icon: Radio,
  },
  {
    title: "Civilian & Plate Lookups",
    icon: Shield,
  },
  {
    title: "Incident Reports",
    icon: FileText,
  },
];

const Index = () => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#02060b] px-5 py-6 text-white sm:px-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(20,35,61,0.26)_0,rgba(2,6,11,0)_46%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[#273244]" />

      <header className="relative z-10 flex items-center justify-between">
        <p className="text-sm font-black uppercase tracking-[-0.02em] text-white sm:text-base">
          Somerville Metro
        </p>
        <button
          type="button"
          onClick={() => setIsLoginOpen(true)}
          className="rounded-full px-3 py-2 text-sm font-bold text-white transition-colors hover:bg-white/5 hover:text-[#4384ff]"
        >
          Sign in
        </button>
      </header>

      <section className="relative z-10 mx-auto flex min-h-[calc(100vh-6rem)] w-full max-w-6xl flex-col items-center justify-center pb-28 pt-14 text-center sm:pt-20">
        <div className="mb-9 inline-flex items-center gap-2 rounded-full border border-[#173053] bg-[#071120] px-4 py-2 shadow-[0_0_30px_rgba(47,112,255,0.12)]">
          <span className="h-2 w-2 rounded-full bg-[#4384ff]" />
          <span className="text-[10px] font-black uppercase tracking-[0.34em] text-[#4384ff]">
            Terminal Online
          </span>
        </div>

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          <h1 className="text-[48px] font-black leading-[0.98] tracking-[-0.06em] text-white sm:text-[72px] lg:text-[88px]">
            Somerville Metro
            <span className="mt-2 block text-[#2f70ff]">CAD/MDT</span>
          </h1>
          <p className="mx-auto mt-8 max-w-[600px] text-base leading-7 text-[#9eb0c7] sm:text-lg">
            Computer-aided dispatch and mobile data terminal for officers of the Somerville Metro Roleplay community.
          </p>
        </div>

        <Button
          type="button"
          onClick={() => setIsLoginOpen(true)}
          className="mt-12 h-12 rounded-md bg-[#2f66ee] px-9 text-base font-black text-white shadow-[0_14px_30px_rgba(47,102,238,0.32)] transition-all hover:-translate-y-0.5 hover:bg-[#3977ff]"
        >
          Sign in
        </Button>

        <div className="mt-20 grid w-full max-w-[980px] gap-6 sm:grid-cols-3">
          {featureCards.map(({ title, icon: Icon }) => (
            <div
              key={title}
              className="group rounded-lg border border-[#1b2738] bg-[#0b1018] px-6 py-9 shadow-[0_18px_42px_rgba(0,0,0,0.22)] transition-all duration-300 hover:-translate-y-1 hover:border-[#2f70ff]/70 hover:bg-[#0d1625]"
            >
              <Icon className="mx-auto h-8 w-8 text-[#4b91ff] transition-transform duration-300 group-hover:scale-110" strokeWidth={2.25} />
              <h2 className="mt-6 text-sm font-black text-white">{title}</h2>
            </div>
          ))}
        </div>
      </section>

      <footer className="fixed inset-x-0 bottom-10 z-10 flex flex-col items-center gap-5 text-center">
        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-[#344158]">
          For roleplay use only · Not affiliated with any real agency
        </p>
        <div className="text-sm text-[#65718a]">
          <MadeWithDyad />
        </div>
      </footer>

      <LastUpdatedBadge />

      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
    </main>
  );
};

export default Index;
