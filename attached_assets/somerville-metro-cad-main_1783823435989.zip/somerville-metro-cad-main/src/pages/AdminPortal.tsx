import { FormEvent, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, Pencil, Search, Shield, Trash2, UserPlus, Users, X } from 'lucide-react';
import { toast } from 'sonner';
import LastUpdatedBadge from '@/components/LastUpdatedBadge';
import { removeCadLocalAccountsByIds } from '@/lib/cad-local-accounts';
import { clearCadSession, getCadSession, type CadSession } from '@/lib/cad-session';

type AdminMember = {
  id: number;
  auth_user_id: string | null;
  username: string;
  discord_username: string;
  discord_id: string;
  email: string;
  community_code: string;
  status: string;
  rank: string;
  role: string;
  created_at: string;
  updated_at: string;
};

type EditMemberForm = Pick<
  AdminMember,
  'auth_user_id' | 'username' | 'discord_username' | 'discord_id' | 'email' | 'community_code' | 'status' | 'rank' | 'role'
>;

type AdminTab = 'members' | 'staff';

type StaffForm = {
  memberId: string;
  rank: string;
};

const STAFF_RANKS = [
  '+',
  'Owner',
  'Co-Owner',
  'Manager',
  'Administrator',
  'Head Moderator',
  'Moderator',
  'Junior Moderator',
] as const;

const ADMIN_ROLE_GROUPS = ['Executive Board', 'Management', 'Admin'];
const STAFF_ROLE_GROUPS = [...ADMIN_ROLE_GROUPS, 'Moderation'];

const ADMIN_CODE = 'ADMIN2026';
const ADMIN_CODE_STORAGE_KEY = 'somerville-admin-code';

const getRoleForRank = (rank: string) => {
  if (rank === '+' || rank === 'Owner' || rank === 'Co-Owner') return 'Executive Board';
  if (rank === 'Manager') return 'Management';
  if (rank === 'Administrator') return 'Admin';
  return 'Moderation';
};

const hasAdminRole = (role: string) => ADMIN_ROLE_GROUPS.some((group) => group.toLowerCase() === role.trim().toLowerCase());

const hasStaffRole = (role: string) => STAFF_ROLE_GROUPS.some((group) => group.toLowerCase() === role.trim().toLowerCase());

const getRankLevel = (rank: string, role: string) => {
  const rankIndex = STAFF_RANKS.findIndex((staffRank) => staffRank.toLowerCase() === rank.trim().toLowerCase());

  if (rankIndex >= 0) {
    return rankIndex;
  }

  const normalizedRole = role.trim().toLowerCase();
  if (normalizedRole === 'executive board') return 0;
  if (normalizedRole === 'management') return 2;
  if (normalizedRole === 'admin') return 3;
  if (normalizedRole === 'moderation') return 4;
  return Number.POSITIVE_INFINITY;
};

const canManageStaffMember = (admin: CadSession | null, member: AdminMember) =>
  Boolean(admin) && admin.id !== member.id && getRankLevel(admin!.rank, admin!.role) < getRankLevel(member.rank, member.role);

const formatDate = (value: string) =>
  new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(new Date(value));

const toEditForm = (member: AdminMember): EditMemberForm => ({
  auth_user_id: member.auth_user_id,
  username: member.username,
  discord_username: member.discord_username,
  discord_id: member.discord_id,
  email: member.email,
  community_code: member.community_code,
  status: member.status,
  rank: member.rank,
  role: member.role,
});

const AdminPortal = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<AdminTab>('members');
  const [members, setMembers] = useState<AdminMember[]>([]);
  const [memberSearch, setMemberSearch] = useState('');
  const [staffSearch, setStaffSearch] = useState('');
  const [staffMemberSearch, setStaffMemberSearch] = useState('');
  const [staffForm, setStaffForm] = useState<StaffForm>({ memberId: '', rank: 'Administrator' });
  const [staffRankDrafts, setStaffRankDrafts] = useState<Record<number, string>>({});
  const [currentAdmin, setCurrentAdmin] = useState<CadSession | null>(null);
  const [expandedMemberId, setExpandedMemberId] = useState<number | null>(null);
  const [editingMemberId, setEditingMemberId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<EditMemberForm | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const [isDeletingAccounts, setIsDeletingAccounts] = useState(false);
  const [deletingMemberId, setDeletingMemberId] = useState<number | null>(null);
  const [savingMemberId, setSavingMemberId] = useState<number | null>(null);
  const [assigningStaffMemberId, setAssigningStaffMemberId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const adminCode = ADMIN_CODE;

  const loadMembers = async () => {
    const response = await fetch('/api/admin/members', {
      headers: { 'x-admin-code': adminCode, accept: 'application/json' },
    });
    const contentType = response.headers.get('content-type') ?? '';

    if (!response.ok) {
      throw new Error('Unable to load members from the shared CAD database.');
    }

    if (!contentType.includes('application/json')) {
      throw new Error('The shared members API is not running yet. Restart the app server and try again.');
    }

    return (await response.json()) as AdminMember[];
  };

  useEffect(() => {
    const initializeMembers = async () => {
      const session = getCadSession();

      if (!session) {
        navigate('/', { replace: true });
        return;
      }

      if (!hasAdminRole(session.role)) {
        toast.error('Admin portal access requires an Executive Board, Management, or Admin role.');
        navigate('/portal', { replace: true });
        return;
      }

      setCurrentAdmin(session);

      try {
        setMembers(await loadMembers());
        setError(null);
      } catch (membersError) {
        setMembers([]);
        setError(membersError instanceof Error ? membersError.message : 'Unable to load all CAD member accounts.');
      } finally {
        setIsLoading(false);
      }
    };

    initializeMembers();
  }, [adminCode, navigate]);

  const handleSignOut = async () => {
    setIsSigningOut(true);
    clearCadSession();
    sessionStorage.removeItem(ADMIN_CODE_STORAGE_KEY);
    toast.success('Signed out of the admin portal.');
    navigate('/', { replace: true });
  };

  const handleDeleteAllAccounts = async () => {
    const confirmed = window.confirm(
      'This will permanently delete every active non-admin CAD signup account from shared MDT storage and log those accounts out. Executive Board, Management, and Admin accounts will be kept. Continue?',
    );

    if (!confirmed) {
      return;
    }

    setIsDeletingAccounts(true);
    setError(null);

    try {
      const response = await fetch('/api/admin/members', {
        method: 'DELETE',
        headers: { 'x-admin-code': adminCode, accept: 'application/json' },
      });
      const contentType = response.headers.get('content-type') ?? '';

      if (!response.ok || !contentType.includes('application/json')) {
        throw new Error('Unable to delete signup accounts from shared MDT storage.');
      }

      const result = (await response.json()) as {
        deleted_count?: number;
        protected_count?: number;
        deleted_ids?: number[];
      };
      const deletedIds = result.deleted_ids ?? [];
      const currentSession = getCadSession();
      removeCadLocalAccountsByIds(deletedIds);
      setMembers(await loadMembers());
      setExpandedMemberId(null);
      setEditingMemberId(null);
      setEditForm(null);
      toast.success(
        `Deleted ${result.deleted_count ?? 0} account${result.deleted_count === 1 ? '' : 's'} and kept ${
          result.protected_count ?? 0
        } protected admin account${result.protected_count === 1 ? '' : 's'}.`,
      );

      if (currentSession && deletedIds.includes(currentSession.id)) {
        clearCadSession();
        sessionStorage.removeItem(ADMIN_CODE_STORAGE_KEY);
        navigate('/', { replace: true });
      }
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : 'Unable to delete signup accounts.');
    } finally {
      setIsDeletingAccounts(false);
    }
  };

  const handleStartEdit = (member: AdminMember) => {
    setExpandedMemberId(member.id);
    setEditingMemberId(member.id);
    setEditForm(toEditForm(member));
  };

  const handleCancelEdit = () => {
    setEditingMemberId(null);
    setEditForm(null);
  };

  const updateMember = async (memberId: number, updates: EditMemberForm) => {
    const response = await fetch('/api/admin/members', {
      method: 'PATCH',
      headers: {
        'content-type': 'application/json',
        'x-admin-code': adminCode,
        accept: 'application/json',
      },
      body: JSON.stringify({ id: memberId, ...updates }),
    });
    const contentType = response.headers.get('content-type') ?? '';

    if (!response.ok || !contentType.includes('application/json')) {
      throw new Error('Unable to save account changes.');
    }

    const updatedMember = (await response.json()) as AdminMember;
    setMembers((current) => current.map((member) => (member.id === updatedMember.id ? updatedMember : member)));
    return updatedMember;
  };

  const handleSaveEdit = async (event: FormEvent<HTMLFormElement>, memberId: number) => {
    event.preventDefault();

    if (!editForm) {
      return;
    }

    setSavingMemberId(memberId);
    setError(null);

    try {
      const updatedMember = await updateMember(memberId, editForm);
      setEditingMemberId(null);
      setEditForm(null);
      toast.success(`Updated ${updatedMember.username}.`);
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Unable to save account changes.');
    } finally {
      setSavingMemberId(null);
    }
  };

  const handleDeleteMember = async (member: AdminMember) => {
    if (hasAdminRole(member.role)) {
      return;
    }

    const confirmed = window.confirm(
      `This will permanently delete ${member.username}'s CAD account data and log that account out. Continue?`,
    );

    if (!confirmed) {
      return;
    }

    setDeletingMemberId(member.id);
    setError(null);

    try {
      const response = await fetch(`/api/admin/members?id=${member.id}`, {
        method: 'DELETE',
        headers: { 'x-admin-code': adminCode, accept: 'application/json' },
      });
      const contentType = response.headers.get('content-type') ?? '';

      if (!response.ok || !contentType.includes('application/json')) {
        throw new Error('Unable to delete this account.');
      }

      const result = (await response.json()) as {
        deleted_count?: number;
        protected_count?: number;
        deleted_ids?: number[];
      };
      const deletedIds = result.deleted_ids ?? [];

      if (result.protected_count) {
        toast.error('Executive Board, Management, and Admin accounts cannot be deleted.');
        return;
      }

      removeCadLocalAccountsByIds(deletedIds);
      setMembers((current) => current.filter((candidate) => !deletedIds.includes(candidate.id)));
      setExpandedMemberId((current) => (current && deletedIds.includes(current) ? null : current));
      if (editingMemberId && deletedIds.includes(editingMemberId)) {
        handleCancelEdit();
      }
      toast.success(`Deleted ${member.username}'s account.`);

      const currentSession = getCadSession();
      if (currentSession && deletedIds.includes(currentSession.id)) {
        clearCadSession();
        sessionStorage.removeItem(ADMIN_CODE_STORAGE_KEY);
        navigate('/', { replace: true });
      }
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : 'Unable to delete this account.');
    } finally {
      setDeletingMemberId(null);
    }
  };

  const updateEditField = (field: keyof EditMemberForm, value: string) => {
    setEditForm((current) => (current ? { ...current, [field]: field === 'auth_user_id' && value === '' ? null : value } : current));
  };

  const handleAssignStaffRole = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const memberId = Number(staffForm.memberId);
    const member = members.find((candidate) => candidate.id === memberId);
    const rank = (manageableStaffRanks.includes(staffForm.rank as (typeof STAFF_RANKS)[number])
      ? staffForm.rank
      : manageableStaffRanks[0] ?? ''
    ).trim();

    if (!member || !rank) {
      setError('Choose a member and select a staff rank.');
      return;
    }

    const role = getRoleForRank(rank);

    if (getRankLevel(rank, role) <= currentAdminLevel) {
      setError('You can only assign staff ranks below your own rank.');
      return;
    }

    setAssigningStaffMemberId(member.id);
    setError(null);

    try {
      const updatedMember = await updateMember(member.id, { ...toEditForm(member), rank, role });
      setStaffForm({ memberId: '', rank: 'Administrator' });
      setStaffMemberSearch('');
      toast.success(`${updatedMember.username} was added to the staff team as ${updatedMember.rank} under ${updatedMember.role}.`);
    } catch (staffError) {
      setError(staffError instanceof Error ? staffError.message : 'Unable to add this member to staff.');
    } finally {
      setAssigningStaffMemberId(null);
    }
  };

  const handleUpdateStaffRank = async (member: AdminMember) => {
    if (!canManageStaffMember(currentAdmin, member)) {
      toast.error('You can only manage staff below your own rank.');
      return;
    }

    const rank = staffRankDrafts[member.id] ?? member.rank;
    const role = getRoleForRank(rank);

    if (getRankLevel(rank, role) <= currentAdminLevel) {
      toast.error('You can only assign staff ranks below your own rank.');
      return;
    }

    setAssigningStaffMemberId(member.id);
    setError(null);

    try {
      const updatedMember = await updateMember(member.id, { ...toEditForm(member), rank, role });
      toast.success(`${updatedMember.username} is now ${updatedMember.rank} under ${updatedMember.role}.`);
    } catch (staffError) {
      setError(staffError instanceof Error ? staffError.message : 'Unable to update this staff member.');
    } finally {
      setAssigningStaffMemberId(null);
    }
  };

  const handleRemoveStaffMember = async (member: AdminMember) => {
    if (!canManageStaffMember(currentAdmin, member)) {
      toast.error('You can only remove staff below your own rank.');
      return;
    }

    const confirmed = window.confirm(`Remove ${member.username} from the staff team?`);

    if (!confirmed) {
      return;
    }

    setAssigningStaffMemberId(member.id);
    setError(null);

    try {
      const updatedMember = await updateMember(member.id, { ...toEditForm(member), rank: 'member', role: 'Community Members' });
      setStaffRankDrafts((current) => {
        const next = { ...current };
        delete next[member.id];
        return next;
      });
      toast.success(`${updatedMember.username} was removed from the staff team.`);
    } catch (staffError) {
      setError(staffError instanceof Error ? staffError.message : 'Unable to remove this staff member.');
    } finally {
      setAssigningStaffMemberId(null);
    }
  };

  const memberSearchTerm = memberSearch.trim().toLowerCase();
  const filteredMembers = members.filter((member) =>
    [member.username, member.rank, member.role, member.email, member.discord_username, member.discord_id, member.auth_user_id ?? '']
      .join(' ')
      .toLowerCase()
      .includes(memberSearchTerm),
  );
  const currentAdminLevel = currentAdmin ? getRankLevel(currentAdmin.rank, currentAdmin.role) : Number.POSITIVE_INFINITY;
  const manageableStaffRanks = STAFF_RANKS.filter((rank) => getRankLevel(rank, getRoleForRank(rank)) > currentAdminLevel);
  const staffMembers = members.filter((member) => hasStaffRole(member.role));
  const nonStaffMembers = members.filter((member) => !hasStaffRole(member.role));
  const staffMemberSearchTerm = staffMemberSearch.trim().toLowerCase();
  const filteredStaffAssignableMembers = nonStaffMembers.filter((member) =>
    [member.username, member.rank, member.role, member.email, member.discord_username, member.discord_id]
      .join(' ')
      .toLowerCase()
      .includes(staffMemberSearchTerm),
  );
  const selectedStaffMember = members.find((member) => member.id === Number(staffForm.memberId)) ?? null;
  const staffSearchTerm = staffSearch.trim().toLowerCase();
  const filteredStaffMembers = staffMembers.filter((member) =>
    [member.username, member.rank, member.role, member.email, member.discord_username, member.discord_id]
      .join(' ')
      .toLowerCase()
      .includes(staffSearchTerm),
  );

  const hasDeletableActiveMembers = members.some(
    (member) => member.status.toLowerCase() === 'active' && !hasAdminRole(member.role),
  );

  return (
    <main className="min-h-screen bg-[#02060b] text-white">
      <div className="flex min-h-screen flex-col lg:flex-row">
        <aside className="border-b border-[#182232] bg-[#03070c] px-5 py-5 lg:fixed lg:inset-y-0 lg:left-0 lg:w-[265px] lg:border-b-0 lg:border-r">
          <div>
            <h1 className="text-xl font-black tracking-[-0.04em] text-white">Admin Portal</h1>
            <p className="mt-2 text-sm font-black leading-none text-[#ff5d5d]">Somerville Metro</p>
            <p className="mt-1 text-[10px] font-black uppercase tracking-[0.22em] text-[#7b8ca7]">
              Administrator Access
            </p>
          </div>

          <nav className="mt-8 flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
            {(['members', 'staff'] as AdminTab[]).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`shrink-0 rounded-md px-4 py-3 text-left text-sm font-semibold capitalize transition-colors ${
                  activeTab === tab
                    ? 'border-l-2 border-[#ff5d5d] bg-[#210b12] text-white'
                    : 'text-[#a8b7cd] hover:bg-[#08111f] hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </nav>

          <button
            type="button"
            onClick={() => navigate('/portal')}
            className="mt-6 flex w-full items-center gap-3 border-t border-[#182232] px-4 pt-6 text-left text-sm font-black uppercase text-[#a8b7cd] transition-colors hover:text-white lg:mt-5"
          >
            <Shield className="h-4 w-4" />
            Member Portal
          </button>
        </aside>

        <section className="flex min-h-screen flex-1 flex-col lg:ml-[265px]">
          <header className="flex items-center justify-between border-b border-[#182232] px-5 py-4 sm:px-8 lg:px-9">
            <p className="text-sm font-black uppercase tracking-[0.08em] text-white">Somerville Metro</p>
            <div className="hidden items-center gap-2 rounded-full border border-[#3a1920] bg-[#19070b] px-4 py-2 sm:flex">
              <span className="h-2 w-2 rounded-full bg-[#ff5d5d]" />
              <span className="text-[10px] font-black uppercase tracking-[0.34em] text-[#ff7070]">
                Admin Terminal
              </span>
            </div>
            <button
              type="button"
              onClick={handleSignOut}
              disabled={isSigningOut}
              className="rounded-full px-3 py-2 text-sm font-bold text-[#dce7f8] transition-colors hover:bg-white/5 hover:text-[#ff7070] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSigningOut ? 'Signing out...' : 'Sign out'}
            </button>
          </header>

          <div className="flex-1 px-5 py-8 sm:px-8 lg:px-9">
            <section className="mb-8">
              <h2 className="text-3xl font-black leading-none tracking-[-0.05em] text-white sm:text-4xl">
                {activeTab === 'members' ? 'Member Management' : 'Staff Management'}
              </h2>
              <p className="mt-2 text-sm text-[#8392aa] sm:text-base">
                {activeTab === 'members'
                  ? 'Search, view, edit, or delete CAD member accounts saved in the shared MDT data storage.'
                  : 'Search for non-staff members, add them to the staff team, and assign a staff rank with the correct role category.'}
              </p>
            </section>

            {activeTab === 'members' ? (
            <section className="rounded-xl border border-[#172235] bg-[#0d1422] p-5 shadow-[0_22px_55px_rgba(0,0,0,0.22)] sm:p-7">
              <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-[#ff7070]" />
                  <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[#ff7070]">
                    All CAD Members
                  </h3>
                </div>
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                  <span className="rounded-full border border-[#263247] bg-[#071120] px-3 py-1 text-center text-[10px] font-black uppercase tracking-[0.18em] text-[#8ea1bb]">
                    {filteredMembers.length} / {members.length} Accounts
                  </span>
                  <button
                    type="button"
                    onClick={handleDeleteAllAccounts}
                    disabled={isDeletingAccounts || isLoading || !hasDeletableActiveMembers}
                    className="inline-flex items-center justify-center gap-2 rounded-full border border-red-400/30 bg-red-500/10 px-4 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-red-100 transition-colors hover:border-red-300/50 hover:bg-red-500/20 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Trash2 className="h-4 w-4" />
                    {isDeletingAccounts ? 'Deleting...' : 'Delete Active Accounts'}
                  </button>
                </div>
              </div>

              <SearchField
                value={memberSearch}
                onChange={setMemberSearch}
                placeholder="Search members by username, rank, role, email, Discord user, Discord ID, or auth user ID"
              />

              {isLoading ? (
                <div className="flex min-h-[280px] items-center justify-center text-sm font-bold text-[#8ea1bb]">
                  Loading members...
                </div>
              ) : error ? (
                <div className="rounded-xl border border-red-500/25 bg-red-500/10 p-5 text-sm font-bold text-red-100">
                  {error}
                </div>
              ) : members.length === 0 ? (
                <div className="flex min-h-[280px] items-center justify-center text-sm italic text-[#526179]">
                  No CAD member accounts are saved in the shared MDT data storage yet.
                </div>
              ) : filteredMembers.length === 0 ? (
                <div className="flex min-h-[280px] items-center justify-center text-sm italic text-[#526179]">
                  No members match your search.
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredMembers.map((member) => {
                    const isExpanded = expandedMemberId === member.id;
                    const isEditing = editingMemberId === member.id && editForm;
                    const isProtected = hasAdminRole(member.role);

                    return (
                      <div
                        key={member.id}
                        className="overflow-hidden rounded-xl border border-[#1a2638] bg-[#070d16]"
                      >
                        <button
                          type="button"
                          onClick={() => setExpandedMemberId(isExpanded ? null : member.id)}
                          className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition-colors hover:bg-[#0b1422]"
                        >
                          <div>
                            <p className="text-base font-black text-white">{member.username}</p>
                            <p className="mt-1 text-xs font-semibold text-[#7b8ca7]">
                              {member.rank} · {member.email}
                            </p>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-emerald-200">
                              {member.status}
                            </span>
                            {isProtected && (
                              <span className="rounded-full border border-[#526179] bg-[#1b2330] px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-[#b8c2d3]">
                                Admin Protected
                              </span>
                            )}
                            <ChevronDown
                              className={`h-5 w-5 text-[#7b8ca7] transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                            />
                          </div>
                        </button>

                        {isExpanded && (
                          <div className="border-t border-[#1a2638] px-5 py-5">
                            <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-end">
                              <button
                                type="button"
                                onClick={() => handleStartEdit(member)}
                                className="inline-flex items-center justify-center gap-2 rounded-full border border-[#2f70ff]/35 bg-[#102145] px-4 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-[#dce7ff] transition-colors hover:bg-[#173163]"
                              >
                                <Pencil className="h-4 w-4" />
                                Edit Account
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteMember(member)}
                                disabled={isProtected || deletingMemberId === member.id}
                                title={isProtected ? 'Executive Board, Management, and Admin accounts cannot be deleted' : undefined}
                                className="inline-flex items-center justify-center gap-2 rounded-full border border-red-400/30 bg-red-500/10 px-4 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-red-100 transition-colors hover:border-red-300/50 hover:bg-red-500/20 disabled:cursor-not-allowed disabled:border-[#3c4656] disabled:bg-[#1a2230] disabled:text-[#738095]"
                              >
                                <Trash2 className="h-4 w-4" />
                                {deletingMemberId === member.id ? 'Deleting...' : 'Delete Account'}
                              </button>
                            </div>

                            {isEditing ? (
                              <form onSubmit={(event) => handleSaveEdit(event, member.id)} className="rounded-xl border border-[#23324a] bg-[#0b111d] p-4">
                                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                                  <EditField label="CAD Username" value={editForm.username} onChange={(value) => updateEditField('username', value)} />
                                  <EditField label="Email" value={editForm.email} onChange={(value) => updateEditField('email', value)} type="email" />
                                  <EditField label="Rank" value={editForm.rank} onChange={(value) => updateEditField('rank', value)} />
                                  <EditField label="Role" value={editForm.role} onChange={(value) => updateEditField('role', value)} />
                                  <EditField label="Discord Username" value={editForm.discord_username} onChange={(value) => updateEditField('discord_username', value)} />
                                  <EditField label="Discord ID" value={editForm.discord_id} onChange={(value) => updateEditField('discord_id', value)} />
                                  <EditField label="Status" value={editForm.status} onChange={(value) => updateEditField('status', value)} />
                                  <EditField label="Community Code" value={editForm.community_code} onChange={(value) => updateEditField('community_code', value)} />
                                  <EditField label="Auth User ID" value={editForm.auth_user_id ?? ''} onChange={(value) => updateEditField('auth_user_id', value)} required={false} />
                                </div>
                                <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:justify-end">
                                  <button
                                    type="button"
                                    onClick={handleCancelEdit}
                                    className="inline-flex items-center justify-center gap-2 rounded-full border border-[#334156] bg-[#111827] px-4 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-[#c7d2e5] transition-colors hover:bg-[#182234]"
                                  >
                                    <X className="h-4 w-4" />
                                    Cancel
                                  </button>
                                  <button
                                    type="submit"
                                    disabled={savingMemberId === member.id}
                                    className="rounded-full bg-[#2f70ff] px-5 py-2 text-[10px] font-black uppercase tracking-[0.16em] text-white transition-colors hover:bg-[#4384ff] disabled:cursor-not-allowed disabled:opacity-60"
                                  >
                                    {savingMemberId === member.id ? 'Saving...' : 'Save Changes'}
                                  </button>
                                </div>
                              </form>
                            ) : (
                              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                                <ProfileField label="Username" value={member.username} />
                                <ProfileField label="Rank" value={member.rank} />
                                <ProfileField label="Role" value={member.role} />
                                <ProfileField label="Email" value={member.email} />
                                <ProfileField label="Discord User" value={member.discord_username} />
                                <ProfileField label="Discord ID" value={member.discord_id} />
                                <ProfileField label="Auth User ID" value={member.auth_user_id} />
                                <ProfileField label="Created" value={formatDate(member.created_at)} />
                                <ProfileField label="Updated" value={formatDate(member.updated_at)} />
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
            ) : (
              <section className="space-y-5">
                <form
                  onSubmit={handleAssignStaffRole}
                  className="rounded-xl border border-[#172235] bg-[#0d1422] p-5 shadow-[0_22px_55px_rgba(0,0,0,0.22)] sm:p-7"
                >
                  <div className="mb-5 flex items-center gap-3">
                    <UserPlus className="h-5 w-5 text-[#ff7070]" />
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[#ff7070]">
                      Add Staff Member
                    </h3>
                  </div>
                  <div className="grid gap-3 lg:grid-cols-[1.4fr_0.8fr_auto] lg:items-start">
                    <div className="rounded-lg border border-[#172235] bg-[#070d16] p-4">
                      <span className="text-[10px] font-black uppercase tracking-[0.18em] text-[#6f7f99]">Member Search</span>
                      <input
                        type="search"
                        value={staffMemberSearch}
                        onChange={(event) => {
                          setStaffMemberSearch(event.target.value);
                          setStaffForm((current) => ({ ...current, memberId: '' }));
                        }}
                        placeholder="Search non-staff members by username, email, or Discord"
                        className="mt-2 h-10 w-full rounded-md border border-[#27354c] bg-[#101827] px-3 text-sm font-bold text-white outline-none transition-colors placeholder:text-[#66748a] focus:border-[#2f70ff]"
                      />
                      {selectedStaffMember ? (
                        <button
                          type="button"
                          onClick={() => setStaffForm((current) => ({ ...current, memberId: '' }))}
                          className="mt-3 w-full rounded-lg border border-[#2f70ff]/35 bg-[#102145] px-3 py-2 text-left text-xs font-bold text-[#dce7ff] transition-colors hover:bg-[#173163]"
                        >
                          Selected: {selectedStaffMember.username} · Click to clear
                        </button>
                      ) : staffMemberSearch.trim() ? (
                        <div className="mt-3 max-h-44 overflow-y-auto rounded-lg border border-[#1a2638] bg-[#080d15]">
                          {filteredStaffAssignableMembers.length === 0 ? (
                            <p className="px-3 py-3 text-xs font-semibold text-[#66748a]">
                              No non-staff members match your search.
                            </p>
                          ) : (
                            filteredStaffAssignableMembers.slice(0, 8).map((member) => (
                              <button
                                key={member.id}
                                type="button"
                                onClick={() => {
                                  setStaffForm((current) => ({ ...current, memberId: String(member.id) }));
                                  setStaffMemberSearch(member.username);
                                }}
                                className="block w-full border-b border-[#172235] px-3 py-3 text-left text-xs font-bold text-white transition-colors last:border-b-0 hover:bg-[#101827]"
                              >
                                {member.username}
                                <span className="mt-1 block text-[11px] text-[#7b8ca7]">{member.email}</span>
                              </button>
                            ))
                          )}
                        </div>
                      ) : null}
                    </div>
                    <label className="block rounded-lg border border-[#172235] bg-[#070d16] p-4">
                      <span className="text-[10px] font-black uppercase tracking-[0.18em] text-[#6f7f99]">Rank</span>
                      <select
                        value={manageableStaffRanks.includes(staffForm.rank as (typeof STAFF_RANKS)[number]) ? staffForm.rank : manageableStaffRanks[0] ?? ''}
                        onChange={(event) => setStaffForm((current) => ({ ...current, rank: event.target.value }))}
                        required
                        disabled={manageableStaffRanks.length === 0}
                        className="mt-2 h-10 w-full rounded-md border border-[#27354c] bg-[#101827] px-3 text-sm font-bold text-white outline-none transition-colors focus:border-[#2f70ff] disabled:cursor-not-allowed disabled:opacity-60"
                      >
                        {manageableStaffRanks.map((rank) => (
                          <option key={rank} value={rank}>
                            {rank}
                          </option>
                        ))}
                      </select>
                      <p className="mt-2 text-[11px] font-semibold text-[#7b8ca7]">
                        Role: {getRoleForRank(manageableStaffRanks.includes(staffForm.rank as (typeof STAFF_RANKS)[number]) ? staffForm.rank : manageableStaffRanks[0] ?? '')}
                      </p>
                    </label>
                    <button
                      type="submit"
                      disabled={assigningStaffMemberId !== null || isLoading || !staffForm.memberId}
                      className="inline-flex h-[74px] items-center justify-center gap-2 rounded-lg bg-[#ff5d5d] px-5 text-[10px] font-black uppercase tracking-[0.16em] text-white transition-colors hover:bg-[#ff7474] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      <UserPlus className="h-4 w-4" />
                      {assigningStaffMemberId !== null ? 'Adding...' : 'Add Staff'}
                    </button>
                  </div>
                  <p className="mt-3 text-xs font-semibold text-[#7b8ca7]">
                    Owner and Co-Owner become Executive Board, Manager becomes Management, Administrator becomes Admin, and moderator ranks become Moderation.
                  </p>
                </form>

                <section className="rounded-xl border border-[#172235] bg-[#0d1422] p-5 shadow-[0_22px_55px_rgba(0,0,0,0.22)] sm:p-7">
                  <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-[#ff7070]" />
                      <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[#ff7070]">
                        Staff Team
                      </h3>
                    </div>
                    <span className="rounded-full border border-[#263247] bg-[#071120] px-3 py-1 text-center text-[10px] font-black uppercase tracking-[0.18em] text-[#8ea1bb]">
                      {staffMembers.length} Staff
                    </span>
                  </div>

                  <SearchField
                    value={staffSearch}
                    onChange={setStaffSearch}
                    placeholder="Search staff by username, role, rank, email, Discord user, or Discord ID"
                  />

                  {isLoading ? (
                    <div className="mt-5 flex min-h-[220px] items-center justify-center text-sm font-bold text-[#8ea1bb]">
                      Loading staff...
                    </div>
                  ) : error ? (
                    <div className="mt-5 rounded-xl border border-red-500/25 bg-red-500/10 p-5 text-sm font-bold text-red-100">
                      {error}
                    </div>
                  ) : filteredStaffMembers.length === 0 ? (
                    <div className="mt-5 flex min-h-[220px] items-center justify-center text-center text-sm italic text-[#526179]">
                      {staffMembers.length === 0 ? 'No staff members have been added yet.' : 'No staff members match your search.'}
                    </div>
                  ) : (
                    <div className="mt-5 grid gap-3 lg:grid-cols-2">
                      {filteredStaffMembers.map((member) => {
                        const canManage = canManageStaffMember(currentAdmin, member);
                        const draftRank = staffRankDrafts[member.id] ?? member.rank;
                        const allowedRanksForMember = STAFF_RANKS.filter(
                          (rank) => getRankLevel(rank, getRoleForRank(rank)) > currentAdminLevel,
                        );

                        return (
                          <div key={member.id} className="rounded-xl border border-[#1a2638] bg-[#070d16] p-5">
                            <div className="flex items-start justify-between gap-4">
                              <div>
                                <p className="text-base font-black text-white">{member.username}</p>
                                <p className="mt-1 text-xs font-semibold text-[#7b8ca7]">{member.email}</p>
                              </div>
                              <span className="rounded-full border border-[#526179] bg-[#1b2330] px-3 py-1 text-[10px] font-black uppercase tracking-[0.16em] text-[#b8c2d3]">
                                {member.rank}
                              </span>
                            </div>
                            <div className="mt-4 grid gap-3 sm:grid-cols-2">
                              <ProfileField label="Role" value={member.role} />
                              <ProfileField label="Discord User" value={member.discord_username} />
                            </div>
                            <div className="mt-4 rounded-lg border border-[#172235] bg-[#0b111d] p-4">
                              <div className="grid gap-3 sm:grid-cols-[1fr_auto_auto] sm:items-end">
                                <label className="block">
                                  <span className="text-[10px] font-black uppercase tracking-[0.18em] text-[#6f7f99]">Edit Rank / Permissions</span>
                                  <select
                                    value={allowedRanksForMember.includes(draftRank as (typeof STAFF_RANKS)[number]) ? draftRank : allowedRanksForMember[0] ?? member.rank}
                                    onChange={(event) =>
                                      setStaffRankDrafts((current) => ({ ...current, [member.id]: event.target.value }))
                                    }
                                    disabled={!canManage || assigningStaffMemberId === member.id || allowedRanksForMember.length === 0}
                                    className="mt-2 h-10 w-full rounded-md border border-[#27354c] bg-[#101827] px-3 text-sm font-bold text-white outline-none transition-colors focus:border-[#2f70ff] disabled:cursor-not-allowed disabled:opacity-60"
                                  >
                                    {allowedRanksForMember.map((rank) => (
                                      <option key={rank} value={rank}>
                                        {rank}
                                      </option>
                                    ))}
                                  </select>
                                  <p className="mt-2 text-[11px] font-semibold text-[#7b8ca7]">
                                    Role: {getRoleForRank(allowedRanksForMember.includes(draftRank as (typeof STAFF_RANKS)[number]) ? draftRank : allowedRanksForMember[0] ?? member.rank)}
                                  </p>
                                </label>
                                <button
                                  type="button"
                                  onClick={() => handleUpdateStaffRank(member)}
                                  disabled={!canManage || assigningStaffMemberId === member.id || allowedRanksForMember.length === 0}
                                  className="rounded-md bg-[#2f70ff] px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-white transition-colors hover:bg-[#4384ff] disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                  {assigningStaffMemberId === member.id ? 'Saving...' : 'Save'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveStaffMember(member)}
                                  disabled={!canManage || assigningStaffMemberId === member.id}
                                  title={!canManage ? 'You can only manage staff below your own rank.' : undefined}
                                  className="rounded-md border border-red-400/30 bg-red-500/10 px-4 py-3 text-[10px] font-black uppercase tracking-[0.16em] text-red-100 transition-colors hover:bg-red-500/20 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                  Remove
                                </button>
                              </div>
                              {!canManage && (
                                <p className="mt-3 text-xs font-semibold text-[#7b8ca7]">
                                  You cannot manage or remove staff at your rank or above.
                                </p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </section>
              </section>
            )}
          </div>

          <LastUpdatedBadge />
        </section>
      </div>
    </main>
  );
};

const SearchField = ({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}) => (
  <label className="mb-5 block rounded-xl border border-[#172235] bg-[#070d16] p-4">
    <span className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.18em] text-[#6f7f99]">
      <Search className="h-4 w-4 text-[#ff7070]" />
      Search
    </span>
    <input
      type="search"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="mt-3 h-11 w-full rounded-md border border-[#27354c] bg-[#101827] px-3 text-sm font-bold text-white outline-none transition-colors placeholder:text-[#66748a] focus:border-[#2f70ff]"
    />
  </label>
);

const ProfileField = ({ label, value }: { label: string; value: string | number | null }) => (
  <div className="rounded-lg border border-[#172235] bg-[#0b111d] p-4">
    <p className="text-[10px] font-black uppercase tracking-[0.18em] text-[#6f7f99]">{label}</p>
    <p className="mt-2 break-words text-sm font-bold text-white">{value ?? 'Not linked'}</p>
  </div>
);

const EditField = ({
  label,
  value,
  onChange,
  type = 'text',
  required = true,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
}) => (
  <label className="block rounded-lg border border-[#172235] bg-[#070d16] p-4">
    <span className="text-[10px] font-black uppercase tracking-[0.18em] text-[#6f7f99]">{label}</span>
    <input
      type={type}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      required={required}
      className="mt-2 h-10 w-full rounded-md border border-[#27354c] bg-[#101827] px-3 text-sm font-bold text-white outline-none transition-colors placeholder:text-[#66748a] focus:border-[#2f70ff]"
    />
  </label>
);

export default AdminPortal;
