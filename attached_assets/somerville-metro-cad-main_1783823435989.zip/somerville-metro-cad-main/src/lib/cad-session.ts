const CAD_SESSION_KEY = 'somerville-cad-session';
const DEFAULT_RANK = 'member';
const DEFAULT_ROLE = 'Community Members';

export type CadSession = {
  id: number;
  username: string;
  email: string;
  rank: string;
  role: string;
  status: string;
};

export const setCadSession = (session: CadSession) => {
  localStorage.setItem(CAD_SESSION_KEY, JSON.stringify(session));
};

export const getCadSession = (): CadSession | null => {
  const raw = localStorage.getItem(CAD_SESSION_KEY);

  if (!raw) {
    return null;
  }

  try {
    const session = JSON.parse(raw) as CadSession;
    const rank = session.rank ?? DEFAULT_RANK;
    const role = session.role?.includes('+') ? 'Admin' : session.role ?? DEFAULT_ROLE;

    return role.toLowerCase() === DEFAULT_RANK && rank.toLowerCase() !== DEFAULT_RANK
      ? { ...session, rank: role, role: rank }
      : { ...session, rank, role };
  } catch {
    localStorage.removeItem(CAD_SESSION_KEY);
    return null;
  }
};

export const clearCadSession = () => {
  localStorage.removeItem(CAD_SESSION_KEY);
};