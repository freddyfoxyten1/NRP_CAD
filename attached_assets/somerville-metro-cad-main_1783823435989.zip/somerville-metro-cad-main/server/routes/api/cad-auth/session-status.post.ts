import { defineHandler } from 'nitro';
import { readBody } from 'nitro/h3';
import { sql } from '../../../utils/db';

type SessionStatusInput = {
  id?: number;
  email?: string;
};

export default defineHandler(async (event) => {
  const body = await readBody<SessionStatusInput>(event);
  const id = Number(body.id);
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';

  if (!Number.isInteger(id) || !email) {
    return { active: false };
  }

  const [account] = await sql<{
    id: number;
    username: string;
    email: string;
    rank: string;
    role: string;
    status: string;
  }[]>`
    SELECT id::int, username, email, rank, role, status
    FROM cad_user_profiles
    WHERE id = ${id} AND lower(email) = ${email}
    LIMIT 1
  `;

  return account ? { active: true, account } : { active: false };
});
