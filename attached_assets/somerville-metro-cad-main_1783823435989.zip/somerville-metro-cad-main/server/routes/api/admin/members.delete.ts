import { createError, defineHandler } from 'nitro';
import { getQuery, getRequestHeaders } from 'nitro/h3';
import { sql } from '../../../utils/db';

const ADMIN_CODE = process.env.ADMIN_PORTAL_CODE ?? 'ADMIN2026';

export default defineHandler(async (event) => {
  const adminCode = getRequestHeaders(event)['x-admin-code'];

  if (adminCode !== ADMIN_CODE) {
    throw createError({ statusCode: 403, statusMessage: 'Admin access required.' });
  }

  const idParam = getQuery(event).id;
  const memberId = Array.isArray(idParam) ? idParam[0] : idParam;

  if (memberId) {
    const id = Number(memberId);

    if (!Number.isInteger(id)) {
      throw createError({ statusCode: 400, statusMessage: 'Invalid member ID.' });
    }

    const [member] = await sql<{ id: number; protected: boolean }[]>`
      SELECT id::int, (lower(role) IN ('executive board', 'management', 'admin')) AS protected
      FROM cad_user_profiles
      WHERE id = ${id}
      LIMIT 1
    `;

    if (!member) {
      return { deleted_count: 0, protected_count: 0 };
    }

    if (member.protected) {
      return { deleted_count: 0, protected_count: 1 };
    }

    const [result] = await sql<{ deleted_count: number; deleted_ids: number[] }[]>`
      WITH deleted AS (
        DELETE FROM cad_user_profiles
        WHERE id = ${id}
        RETURNING id::int
      )
      SELECT
        COUNT(*)::int AS deleted_count,
        COALESCE(array_agg(id), '{}'::int[]) AS deleted_ids
      FROM deleted
    `;

    return { deleted_count: result?.deleted_count ?? 0, deleted_ids: result?.deleted_ids ?? [], protected_count: 0 };
  }

  const [result] = await sql<{ deleted_count: number; protected_count: number; deleted_ids: number[] }[]>`
    WITH protected AS (
      SELECT COUNT(*)::int AS protected_count
      FROM cad_user_profiles
      WHERE lower(status) = 'active' AND lower(role) IN ('executive board', 'management', 'admin')
    ),
    deleted AS (
      DELETE FROM cad_user_profiles
      WHERE lower(status) = 'active' AND lower(role) NOT IN ('executive board', 'management', 'admin')
      RETURNING id::int
    )
    SELECT
      (SELECT COUNT(*)::int FROM deleted) AS deleted_count,
      (SELECT COALESCE(array_agg(id), '{}'::int[]) FROM deleted) AS deleted_ids,
      (SELECT protected_count FROM protected) AS protected_count
  `;

  return result ?? { deleted_count: 0, deleted_ids: [], protected_count: 0 };
});
