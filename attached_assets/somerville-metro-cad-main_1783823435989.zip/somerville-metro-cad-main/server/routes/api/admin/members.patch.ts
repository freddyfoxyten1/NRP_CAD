import { createError, defineHandler } from 'nitro';
import { getRequestHeaders, readBody } from 'nitro/h3';
import { sql } from '../../../utils/db';

const ADMIN_CODE = process.env.ADMIN_PORTAL_CODE ?? 'ADMIN2026';

type UpdateMemberInput = {
  id?: number;
  username?: string;
  discord_username?: string;
  discord_id?: string;
  email?: string;
  community_code?: string;
  status?: string;
  rank?: string;
  role?: string;
  auth_user_id?: string | null;
};

const clean = (value: unknown) => (typeof value === 'string' ? value.trim() : '');

export default defineHandler(async (event) => {
  const adminCode = getRequestHeaders(event)['x-admin-code'];

  if (adminCode !== ADMIN_CODE) {
    throw createError({ statusCode: 403, statusMessage: 'Admin access required.' });
  }

  const body = await readBody<UpdateMemberInput>(event);
  const id = Number(body.id);

  if (!Number.isInteger(id)) {
    throw createError({ statusCode: 400, statusMessage: 'Invalid member ID.' });
  }

  const username = clean(body.username);
  const discordUsername = clean(body.discord_username);
  const discordId = clean(body.discord_id);
  const email = clean(body.email).toLowerCase();
  const communityCode = clean(body.community_code).toUpperCase();
  const status = clean(body.status).toLowerCase();
  const rank = clean(body.rank);
  const role = clean(body.role).toLowerCase();
  const authUserId = body.auth_user_id === null ? null : clean(body.auth_user_id) || null;

  if (!username || !discordUsername || !discordId || !email || !communityCode || !status || !rank || !role) {
    throw createError({ statusCode: 400, statusMessage: 'All editable account fields are required.' });
  }

  const [member] = await sql`
    UPDATE cad_user_profiles
    SET
      auth_user_id = ${authUserId},
      username = ${username},
      discord_username = ${discordUsername},
      discord_id = ${discordId},
      email = ${email},
      community_code = ${communityCode},
      status = ${status},
      rank = ${rank},
      role = ${role},
      updated_at = now()
    WHERE id = ${id}
    RETURNING
      id::int,
      auth_user_id,
      username,
      discord_username,
      discord_id,
      email,
      community_code,
      status,
      rank,
      role,
      created_at::text,
      updated_at::text
  `;

  if (!member) {
    throw createError({ statusCode: 404, statusMessage: 'Member not found.' });
  }

  return member;
});
