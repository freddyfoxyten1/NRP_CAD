import { createError, defineHandler } from 'nitro';
import { getRequestHeaders } from 'nitro/h3';
import { sql } from '../../../utils/db';

const ADMIN_CODE = process.env.ADMIN_PORTAL_CODE ?? 'ADMIN2026';

export type AdminMember = {
  id: number;
  auth_user_id: string | null;
  username: string;
  discord_username: string;
  discord_id: string;
  email: string;
  community_code: string;
  status: string;
  rank: string;
  role: string;
  created_at: string;
  updated_at: string;
};

export default defineHandler(async (event) => {
  const adminCode = getRequestHeaders(event)['x-admin-code'];

  if (adminCode !== ADMIN_CODE) {
    throw createError({ statusCode: 403, statusMessage: 'Admin access required.' });
  }

  return sql<AdminMember[]>`
    SELECT
      id::int,
      auth_user_id,
      username,
      discord_username,
      discord_id,
      email,
      community_code,
      status,
      rank,
      role,
      created_at::text,
      updated_at::text
    FROM cad_user_profiles
    ORDER BY created_at DESC
  `;
});
