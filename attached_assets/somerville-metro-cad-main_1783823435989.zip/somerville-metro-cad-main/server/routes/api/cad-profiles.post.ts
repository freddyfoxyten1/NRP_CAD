import { createError, defineHandler } from 'nitro';
import { readBody } from 'nitro/h3';
import { sql } from '../../utils/db';

const REQUIRED_COMMUNITY_CODE = 'SMR2026';
const DEFAULT_RANK = 'member';
const DEFAULT_ROLE = 'Community Members';
const DEFAULT_STATUS = 'active';

type CadProfileInput = {
  auth_user_id?: string;
  username?: string;
  discord_username?: string;
  discord_id?: string;
  email?: string;
  community_code?: string;
  role?: string;
  password_salt?: string;
  password_hash?: string;
};

const requireString = (value: unknown, field: string) => {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw createError({ statusCode: 400, statusMessage: `${field} is required.` });
  }

  return value.trim();
};

export default defineHandler(async (event) => {
  const body = await readBody<CadProfileInput>(event);
  const authUserId = requireString(body.auth_user_id, 'Auth user ID');
  const username = requireString(body.username, 'Username');
  const discordUsername = requireString(body.discord_username, 'Discord username');
  const discordId = requireString(body.discord_id, 'Discord ID');
  const email = requireString(body.email, 'Email').toLowerCase();
  const communityCode = requireString(body.community_code, 'Community code').toUpperCase();
  const role = typeof body.role === 'string' && body.role.trim() ? body.role.trim().toLowerCase() : DEFAULT_ROLE;
  const passwordSalt = requireString(body.password_salt, 'Password salt');
  const passwordHash = requireString(body.password_hash, 'Password hash');

  if (communityCode !== REQUIRED_COMMUNITY_CODE) {
    throw createError({ statusCode: 403, statusMessage: 'Invalid community code.' });
  }

  const [profile] = await sql`
    INSERT INTO cad_user_profiles (
      auth_user_id,
      username,
      discord_username,
      discord_id,
      email,
      community_code,
      status,
      rank,
      role,
      password_salt,
      password_hash
    ) VALUES (
      ${authUserId},
      ${username},
      ${discordUsername},
      ${discordId},
      ${email},
      ${communityCode},
      ${DEFAULT_STATUS},
      ${DEFAULT_RANK},
      ${role},
      ${passwordSalt},
      ${passwordHash}
    )
    ON CONFLICT (email) DO UPDATE SET
      auth_user_id = EXCLUDED.auth_user_id,
      username = EXCLUDED.username,
      discord_username = EXCLUDED.discord_username,
      discord_id = EXCLUDED.discord_id,
      community_code = EXCLUDED.community_code,
      status = EXCLUDED.status,
      role = EXCLUDED.role,
      password_salt = EXCLUDED.password_salt,
      password_hash = EXCLUDED.password_hash,
      updated_at = now()
    RETURNING id::int
  `;

  return profile;
});
