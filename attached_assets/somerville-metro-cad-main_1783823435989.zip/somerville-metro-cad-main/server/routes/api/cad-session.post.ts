import { defineHandler, createError } from 'nitro';

export default defineHandler(async () => {
  throw createError({ statusCode: 501, statusMessage: 'Session endpoint not used on server.' });
});