import { defineHandler } from 'nitro';
import { getRequestHeaders, getRequestURL, readRawBody } from 'nitro/h3';

const NEON_AUTH_BASE_URL = process.env.NEON_AUTH_BASE_URL;
const API_AUTH_PREFIX = '/api/auth';

const FORWARDED_REQUEST_HEADERS = new Set([
  'accept',
  'accept-language',
  'authorization',
  'content-type',
  'cookie',
  'origin',
  'referer',
  'user-agent',
  'x-forwarded-for',
]);

const rewriteCookieForHttp = (cookie: string) => {
  let rewritten = cookie
    .replaceAll('__Secure-', '__Secure_')
    .replaceAll('__Host-', '__Host_');

  rewritten = rewritten
    .replaceAll('; Secure', '')
    .replaceAll(';Secure', '')
    .replaceAll('; Partitioned', '')
    .replaceAll(';Partitioned', '');

  rewritten = rewritten.replace(/;[ ]*Domain=[^;]*/gi, '');

  return rewritten
    .replaceAll('; SameSite=None', '; SameSite=Lax')
    .replaceAll(';SameSite=None', ';SameSite=Lax');
};

export default defineHandler(async (event) => {
  if (!NEON_AUTH_BASE_URL) {
    return new Response('NEON_AUTH_BASE_URL is not configured.', { status: 500 });
  }

  const url = getRequestURL(event);
  const upstreamPath = url.pathname.startsWith(API_AUTH_PREFIX)
    ? url.pathname.slice(API_AUTH_PREFIX.length) || '/'
    : url.pathname;
  const upstreamUrl = `${NEON_AUTH_BASE_URL}${upstreamPath}${url.search}`;

  const forwardedHeaders = new Headers();
  const incomingHeaders = getRequestHeaders(event);

  for (const [key, value] of Object.entries(incomingHeaders)) {
    const headerName = key.toLowerCase();

    if (!value || !FORWARDED_REQUEST_HEADERS.has(headerName)) {
      continue;
    }

    forwardedHeaders.set(headerName, value);
  }

  const cookieHeader = forwardedHeaders.get('cookie');
  if (cookieHeader) {
    const restoredCookie = cookieHeader
      .replaceAll('__Secure_', '__Secure-')
      .replaceAll('__Host_', '__Host-');
    forwardedHeaders.set('cookie', restoredCookie);
  }

  const method = event.method;
  const body = method === 'GET' || method === 'HEAD' ? undefined : await readRawBody(event, false);

  const upstream = await fetch(upstreamUrl, {
    method,
    headers: forwardedHeaders,
    body,
    redirect: 'manual',
  });

  const responseHeaders = new Headers();
  upstream.headers.forEach((value, key) => {
    if (key.toLowerCase() !== 'set-cookie') {
      responseHeaders.set(key, value);
    }
  });

  const setCookies =
    (upstream.headers as Headers & { getSetCookie?: () => string[] }).getSetCookie?.() ?? [];

  for (const cookie of setCookies) {
    responseHeaders.append(
      'set-cookie',
      url.protocol === 'http:' ? rewriteCookieForHttp(cookie) : cookie,
    );
  }

  return new Response(upstream.body, {
    status: upstream.status,
    statusText: upstream.statusText,
    headers: responseHeaders,
  });
});
