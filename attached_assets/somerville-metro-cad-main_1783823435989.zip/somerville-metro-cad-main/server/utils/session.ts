const NEON_AUTH_BASE_URL = process.env.NEON_AUTH_BASE_URL;

export type Session = {
  user: {
    id: string;
    name: string;
    email: string;
    emailVerified: boolean;
  };
} | null;

export const getSessionFromCookie = async (cookieHeader: string | null): Promise<Session> => {
  if (!cookieHeader || !NEON_AUTH_BASE_URL) {
    return null;
  }

  const cookie = cookieHeader
    .replaceAll('__Secure_', '__Secure-')
    .replaceAll('__Host_', '__Host-');

  const response = await fetch(`${NEON_AUTH_BASE_URL}/get-session`, {
    headers: { cookie },
  });

  if (!response.ok) {
    return null;
  }

  const session = (await response.json()) as Session;
  return session?.user ? session : null;
};
